import React from 'react'
import Header from './Header';
const App = () => {
  return (
    <div>
            <Header />
            {/* Other components or content */}
        </div>
  )
}

export default App